#define GML_NEWLINE                     1
#define GML_END                         2
#define GML_CLOSE                       3
#define GML_OPEN                        4
#define GML_KEYWORD                     5
#define GML_EQ                          6
#define GML_VALUE                       7
#define GML_COORD                       8
