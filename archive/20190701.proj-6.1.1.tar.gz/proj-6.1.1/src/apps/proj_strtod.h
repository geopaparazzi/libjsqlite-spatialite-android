/* Internal header for proj_strtod.c */

double proj_strtod(const char *str, char **endptr);
double proj_atof(const char *str);
