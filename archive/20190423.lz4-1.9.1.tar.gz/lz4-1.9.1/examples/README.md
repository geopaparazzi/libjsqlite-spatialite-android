# LZ4 examples

All examples are GPL-v2 licensed.

## Documents

 - [Streaming API Basics](streaming_api_basics.md)
 - Examples
     - [Double Buffer](blockStreaming_doubleBuffer.md)
     - [Line by Line Text Compression](blockStreaming_lineByLine.md)
     - [Dictionary Random Access](dictionaryRandomAccess.md)
